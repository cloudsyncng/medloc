import 'package:equatable/equatable.dart';

class Specialist extends Equatable {}
