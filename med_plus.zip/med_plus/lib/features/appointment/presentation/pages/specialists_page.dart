import 'package:flutter/material.dart';

class SpecialistPage extends StatefulWidget {
  SpecialistPage({Key key}) : super(key: key);

  @override
  _SpecialistPageState createState() => _SpecialistPageState();
}

class _SpecialistPageState extends State<SpecialistPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold();
  }
}
