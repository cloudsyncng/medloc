import 'package:flutter/material.dart';

class HospitalsPage extends StatefulWidget {
  HospitalsPage({Key key}) : super(key: key);

  @override
  _HospitalsPageState createState() => _HospitalsPageState();
}

class _HospitalsPageState extends State<HospitalsPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold();
  }
}
