import 'package:flutter/material.dart';

class AppointmentsPage extends StatefulWidget {
  AppointmentsPage({Key key}) : super(key: key);

  @override
  _AppointmentsPageState createState() => _AppointmentsPageState();
}

class _AppointmentsPageState extends State<AppointmentsPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold();
  }
}
