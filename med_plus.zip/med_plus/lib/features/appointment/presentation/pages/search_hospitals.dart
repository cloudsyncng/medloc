import 'package:flutter/material.dart';

class SearchHospitals extends StatefulWidget {
  SearchHospitals({Key key}) : super(key: key);

  @override
  _SearchHospitalsState createState() => _SearchHospitalsState();
}

class _SearchHospitalsState extends State<SearchHospitals> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: <Widget>[
          Center(
            child: Text("MAP GOES HERE!!!!!!!"),
          )
        ],
      ),
    );
  }
}
